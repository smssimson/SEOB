const {readFileSync}=require('fs'),vm=require('vm'),{webcrypto}=require('crypto');
const source=readFileSync(require('path').join(__dirname,'../recovery-v92.js'),'utf8');
async function run(path){let value='a'.repeat(600),writes=0;
const s=source.replace("if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();",`db={};write=async()=>{globalThis.writes++};all=async()=>[];globalThis.testSnapshot=snapshot;globalThis.moduleDetected=module;`);
const ctx={location:{pathname:path},document:{visibilityState:'visible',getElementById:()=>null},localStorage:{length:1,key:()=> 'smetric-drawing-site-v40-test',getItem:()=>value},navigator:{},crypto:webcrypto,TextEncoder,console,writes:0};vm.createContext(ctx);vm.runInContext(s,ctx);
if(ctx.moduleDetected!=='drawing')throw Error('module detection failed '+path);
await ctx.testSnapshot();await ctx.testSnapshot();if(ctx.writes!==1)throw Error('unchanged content duplicated');
value=value.slice(0,300)+'b'+value.slice(301);await ctx.testSnapshot();if(ctx.writes!==2)throw Error('middle edit missed');
console.log('PASS',path,'unchanged snapshot skipped; same-length middle edit captured');}
(async()=>{await run('/SEOB/drawing/');await run('/SEOB/drawing/index.html')})().catch(e=>{console.error(e);process.exitCode=1});
