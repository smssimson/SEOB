const fs=require('fs'),vm=require('vm'),assert=require('assert');
let checks=0;const ok=(x)=>{assert(x);checks++};
class E{
 constructor(tag='div'){this.tagName=tag.toUpperCase();this.children=[];this.attrs={};this.className='';this.id='';this.classList={toggle:(c,on)=>{const a=new Set(this.className.split(' ').filter(Boolean));on?a.add(c):a.delete(c);this.className=[...a].join(' ')}}}
 setAttribute(k,v){this.attrs[k]=v}getAttribute(k){return this.attrs[k]}
 append(...a){a.forEach(e=>{e.remove();this.children.push(e);e.parent=this})} appendChild(e){this.append(e)}
 remove(){if(this.parent)this.parent.children=this.parent.children.filter(x=>x!==this);this.parent=null}
 replaceWith(e){const p=this.parent,i=p.children.indexOf(this);this.remove();p.children.splice(i,0,e);e.parent=p}
 replaceChildren(...a){[...this.children].forEach(e=>e.remove());this.append(...a)}
 get firstChild(){return this.children[0]||null}
 matches(s){if(s.startsWith('#'))return this.id===s.slice(1);if(s.startsWith('.'))return this.className.split(' ').includes(s.slice(1));const m=s.match(/^(\w+)\[onclick="(.*)"\]$/);return m?this.tagName===m[1].toUpperCase()&&this.attrs.onclick===m[2]:this.tagName===s.toUpperCase()}
 querySelectorAll(s){const out=[];for(const e of this.children){if(s.split(',').some(t=>e.matches(t)))out.push(e);out.push(...e.querySelectorAll(s))}return out}
 querySelector(s){return this.querySelectorAll(s)[0]||null}focus(){this.focused=true}
}
const root=new E(),panel=new E(),old=new E(),deck=new E();panel.className='sm43-tool-panel';old.className='sm43-tabs';deck.className='sm43-deck';root.append(panel);panel.append(old,deck);
const content=[];for(let i=0;i<2;i++){const g=new E(),c=new E();c.className='sm43-group-content';g.append(c);deck.append(g);content.push(c)}
const controls={};for(const id of ['modeSelect','modeErase','repeatToggle','eraseMode','modeFree','modePoints']){const e=new E('button');e.id=id;e.onclick=()=>id;controls[id]=e;content[0].append(e)}
const toolbar=new E();toolbar.className='toolbar';const member=new E('button');member.id='modeColumn';toolbar.append(member);content[0].append(toolbar);
const undo=new E('button');undo.setAttribute('onclick','undo()');content[1].append(undo);const proxy=new E('button');proxy.id='sm57UndoField';content[0].append(proxy);
const label=new E('label'),range=new E('input');range.id='eraseSize';label.append(range);content[1].append(label);
const output=new E('section');output.className='sm-drawing-output';const save=new E('button');save.setAttribute('onclick','saveJSON()');output.append(save);root.append(output);
const source=fs.readFileSync('sarch-workspace-v142.js','utf8');const start=source.indexOf('function organizeDrawing(){'),end=source.indexOf('\nfunction install(){',start);
const context={moduleKey:'drawing',document:{createElement:t=>new E(t)},pick:s=>root.querySelector(s)};vm.createContext(context);vm.runInContext(source.slice(start,end)+';organizeDrawing();',context);
const tabs=root.querySelector('#sarchDrawingTabs144');ok(tabs.children.map(x=>x.textContent).join(',')==='그리기,부재,편집,출력');
for(const [id,n] of [['modeFree',0],['modePoints',0],['modeColumn',1],['modeSelect',2],['modeErase',2],['eraseMode',2],['eraseSize',2]])ok(root.querySelector('#sarchDrawingPanel144-'+n).querySelector('#'+id));
ok(root.querySelector('#sarchDrawingPanel144-3').querySelector('button[onclick="saveJSON()"]')===save);ok(root.querySelector('#modeSelect')===controls.modeSelect);ok(controls.modeSelect.onclick()==='modeSelect');ok(!root.querySelector('#sm57UndoField'));
tabs.children[2].onclick();ok(deck.children.filter(x=>!x.hidden).length===1&&deck.children[2].hidden===false);tabs.children[2].onkeydown({key:'ArrowRight',preventDefault(){}});ok(deck.children[3].hidden===false&&tabs.children[3].focused);
vm.runInContext('organizeDrawing()',context);ok(root.querySelectorAll('#sarchDrawingTabs144').length===1);
console.log('PASS v144 tool DOM checks:',checks);
